Notes:
Drag and Drop import work best with .VCF files created by my application!
I could not get the ez-vcard libraries to work. I did my absolute best given my situation.
